/**
 * 元素定位工具 - 用于根据坐标获取元素信息
 * 在页面初始化时注入，后续可直接调用
 */

(function() {
    // 防止重复注入
    if (window.__elementLocatorUtils) {
        return;
    }
    // 获取iframe实际的上下文
    function getIframeDocument(iframe_list){
        let iframe_document = document;
        for (let iframe of iframe_list){
            const ele = document.evaluate(
                iframe.xpath,
                iframe_document,
                null,
                XPathResult.FIRST_ORDERED_NODE_TYPE,
                null
            ).singleNodeValue;
            if (ele == null){
                return false
            }
            iframe_document = ele.contentDocument;
        }
        return iframe_document;
    }
    function isSameElement(locator1, type1, locator2, type2, iframe_list) {
        // 根据类型获取第一个元素
        let elem1 = null;
        iframe_document = getIframeDocument(iframe_list)
        if (iframe_document == false){
            return false
        }
        if (type1 === 'xpath') {
            const result = document.evaluate(
                locator1,
                iframe_document,
                null,
                XPathResult.FIRST_ORDERED_NODE_TYPE,
                null
            );
            elem1 = result.singleNodeValue;
        } else if (type1 === 'selector') {
            elem1 = document.querySelector(locator1);
        } else {
            console.error('type1 必须是 "xpath" 或 "selector"');
            return false;
        }

        // 根据类型获取第二个元素
        let elem2 = null;
        if (type2 === 'xpath') {
            const result = document.evaluate(
                locator2,
                iframe_document,
                null,
                XPathResult.FIRST_ORDERED_NODE_TYPE,
                null
            );
            elem2 = result.singleNodeValue;
        } else if (type2 === 'selector') {
            elem2 = document.querySelector(locator2);
        } else {
            console.error('type2 必须是 "xpath" 或 "selector"');
            return false;
        }

        // 检查是否都找到了元素，并且是同一个
        if (!elem1 || !elem2) {
            // 至少有一个没找到
            return false;
        }

        // 比较是否是同一个DOM节点
        return elem1 === elem2;
    }

    /**
     * 生成相对XPath（使用智能XPath生成器）
     * 优先使用 window.getElementXPath（来自 dom_exporter_all_in_one.js）
     * 如果不可用，回退到简单的XPath生成逻辑
     */
    function getRelativeXPath(element) {
        // 优先使用智能XPath生成器
        if (window.getElementXPath && window.SmartXPathGenerator) {
            try {
                // 使用智能生成器，确保唯一性
                const xpath = window.getElementXPath(element, {
                    debug: false,
                    ensureUnique: true
                });
                if (xpath) {
                    return xpath;
                }
            } catch (e) {
                console.warn('[ElementLocator] 智能XPath生成失败，使用备用方案:', e);
            }
        }

        // 备用方案：简单的XPath生成逻辑
//        if (element.id) {
//            return `//*[@id="${element.id}"]`;
//        }
//
//        const paths = [];
//        let current = element;
//
//        while (current && current.nodeType === Node.ELEMENT_NODE) {
//            let index = 0;
//            let sibling = current.previousSibling;
//
//            // 计算同名兄弟节点中的索引
//            while (sibling) {
//                if (sibling.nodeType === Node.ELEMENT_NODE &&
//                    sibling.nodeName === current.nodeName) {
//                    index++;
//                }
//                sibling = sibling.previousSibling;
//            }
//
//            const tagName = current.nodeName.toLowerCase();
//            const pathIndex = index > 0 ? `[${index + 1}]` : '';
//            paths.unshift(`${tagName}${pathIndex}`);
//
//            // 如果有ID或到达body，停止向上遍历
//            if (current.id || tagName === 'body') {
//                break;
//            }
//
//            current = current.parentNode;
//        }
//
//        return '//' + paths.join('/');
    }

    /**
     * 生成CSS Selector（相对路径）
     */
    function getRelativeSelector(element) {
        if (element.id) {
            return `#${element.id}`;
        }

        const paths = [];
        let current = element;

        while (current && current.nodeType === Node.ELEMENT_NODE) {
            let selector = current.nodeName.toLowerCase();

            // 添加类名
            if (current.className && typeof current.className === 'string') {
                const classes = current.className.trim().split(/\s+/).filter(c => c);
                if (classes.length > 0) {
                    selector += '.' + classes.join('.');
                }
            }

            // 如果有唯一的类名或ID，可以停止
            if (current.id) {
                paths.unshift(`#${current.id}`);
                break;
            }

            // 计算nth-child索引
            let index = 1;
            let sibling = current.previousElementSibling;
            while (sibling) {
                if (sibling.nodeName === current.nodeName) {
                    index++;
                }
                sibling = sibling.previousElementSibling;
            }

            // 如果有多个同类型兄弟节点，添加nth-child
            const siblings = current.parentNode ?
                Array.from(current.parentNode.children).filter(
                    el => el.nodeName === current.nodeName
                ) : [];
            if (siblings.length > 1) {
                selector += `:nth-child(${index})`;
            }

            paths.unshift(selector);

            if (current.nodeName.toLowerCase() === 'body') {
                break;
            }

            current = current.parentNode;
        }

        return paths.join(' > ');
    }

    /**
     * 获取元素文本
     * 优先取直接子文本节点（innerText-like），避免把整个子树文字拼在一起
     */
    function getElementText(element) {
        const tag = element.tagName ? element.tagName.toLowerCase() : '';

        // 输入框取 value / placeholder
        if (tag === 'input' || tag === 'textarea') {
            return (element.value || element.placeholder || '').substring(0, 100);
        }

        // 先尝试只取直接子文本节点拼合（更精准）
        let directText = '';
        for (const node of element.childNodes) {
            if (node.nodeType === Node.TEXT_NODE) {
                directText += node.textContent;
            }
        }
        directText = directText.trim();
        if (directText.length >= 2) {
            return directText.length > 100 ? directText.substring(0, 100) + '...' : directText;
        }

        // 回退：取 textContent（去除多余空白）
        let text = (element.textContent || '').replace(/\s+/g, ' ').trim();
        return text.length > 100 ? text.substring(0, 100) + '...' : text;
    }

    /**
     * 计算元素索引（在所有匹配的元素中）
     */
    function getElementIndex(element, xpath) {
        let index = 0;

        // 尝试通过xpath查找所有匹配元素
        try {
            const xpathResult = document.evaluate(
                xpath,
                document,
                null,
                XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
                null
            );

            for (let i = 0; i < xpathResult.snapshotLength; i++) {
                if (xpathResult.snapshotItem(i) === element) {
                    index = i;
                    break;
                }
            }
        } catch (e) {

        }

        return index >= 0 ? index : 0;
    }

    /**
     * 根据坐标获取元素信息
     * @param {number} x - X坐标
     * @param {number} y - Y坐标
     * @returns {Object} 元素信息对象
     */
    function getActualElement(element, x, y) {
        let iframes = []; // 本函数内部维护遇到的 iframes

        function traverse(el) {
            console.log('当前检查的元素:', el ? el.tagName?.toLowerCase() : 'null/undefined');

            if (el && el.tagName && el.tagName.toLowerCase() === 'iframe') {
                iframes.push(el);
                try {
                    const iframeRect = el.getBoundingClientRect()
                    const doc = el.contentDocument;
                    if (doc) {
                        const innerEl = doc.elementFromPoint(x - iframeRect.left, y - iframeRect.top);
                        if (innerEl) {
                            return traverse(innerEl); // 递归
                        }
                    } else {
                        console.log('⚠️ 无法访问 iframe 的 contentDocument');
                    }
                } catch (e) {
                    console.error('❌ 无法访问该 iframe（可能跨域）:', e);
                }
            }
            return el; // 返回当前元素（可能是最终元素）
        }
        const finalEl = traverse(element);
        return {
            finalElement: finalEl,
            iframes: iframes
        };
    }
    /**
     * 在 querySelectorAll / 文本匹配结果中，按从上到下、从左到右排序后，
     * 找到目标元素的索引位置
     */
    function getMatchIndexByPosition(allElements, targetElement) {
        if (!allElements || allElements.length <= 1) return 0;
        const sorted = Array.from(allElements)
            .map(el => ({ el, rect: el.getBoundingClientRect() }))
            .filter(o => o.rect.width > 0 && o.rect.height > 0)
            .sort((a, b) => {
                const dy = a.rect.top - b.rect.top;
                if (Math.abs(dy) > 5) return dy;
                return a.rect.left - b.rect.left;
            });
        for (let i = 0; i < sorted.length; i++) {
            if (sorted[i].el === targetElement) return i;
        }
        return 0;
    }

    /**
     * 根据文本内容查找所有匹配的可见元素（与 Playwright getByText 语义对齐）
     */
    function findElementsByText(searchText) {
        if (!searchText) return [];
        const clean = searchText.replace(/\.\.\.$/, '').trim().toLowerCase();
        if (!clean) return [];
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, null);
        const matched = [];
        let node;
        while ((node = walker.nextNode())) {
            const rect = node.getBoundingClientRect();
            if (rect.width === 0 || rect.height === 0) continue;
            const nodeText = (node.textContent || '').trim().toLowerCase();
            const val = (node.value || node.placeholder || '').toLowerCase();
            if (nodeText.includes(clean) || val.includes(clean)) {
                // 优先叶子节点：如果子元素也匹配，跳过父容器
                let hasMatchedChild = false;
                for (const child of node.children) {
                    const ct = (child.textContent || '').trim().toLowerCase();
                    if (ct.includes(clean)) { hasMatchedChild = true; break; }
                }
                if (!hasMatchedChild) matched.push(node);
            }
        }
        return matched;
    }

    /**
     * 交互标签白名单
     */
    const INTERACTIVE_TAGS = new Set(['a', 'button', 'input', 'select', 'textarea', 'label', 'summary', 'details', 'area']);

    /**
     * 判断元素是否为可交互元素
     */
    function isInteractive(el) {
        if (!el || el.nodeType !== Node.ELEMENT_NODE) return false;
        const tag = el.tagName.toLowerCase();
        if (INTERACTIVE_TAGS.has(tag)) return true;
        const role = (el.getAttribute('role') || '').toLowerCase();
        if (['button', 'link', 'checkbox', 'radio', 'tab', 'option', 'menuitem'].includes(role)) return true;
        if (el.hasAttribute('onclick') || el.hasAttribute('ng-click') || el.hasAttribute('@click')) return true;
        if (el.tabIndex >= 0 && tag !== 'div' && tag !== 'span') return true;
        return false;
    }

    /**
     * 给定初始命中元素，找到最合适的可交互祖先（最多向上 6 层）
     * 如果祖先中有 <a> 包含坐标，优先返回 <a>
     */
    function findBestInteractiveElement(el) {
        if (!el) return el;
        // 先找最近的可交互祖先（含自身）
        let cur = el;
        for (let i = 0; i < 6 && cur && cur !== document.body; i++) {
            if (isInteractive(cur)) return cur;
            cur = cur.parentElement;
        }
        // 找不到可交互祖先时，返回原始元素
        return el;
    }

    function getElementInfoByCoordinates(x, y) {
        let element = document.elementFromPoint(x, y);
        if (!element) {
            return { success: false, message: '未找到元素' };
        }

        result = getActualElement(element, x, y)
        element = result.finalElement;

        // 如果命中元素本身不可交互，向上找最近的可交互祖先
        element = findBestInteractiveElement(element) || element;

        const xpath = getRelativeXPath(element);
        const cssSelector = getRelativeSelector(element);
        const text = getElementText(element);
        const index = getElementIndex(element, xpath);
        const boundingBox = element.getBoundingClientRect();

        // 计算 CSS 选择器匹配索引
        let cssMatchIndex = 0;
        let cssMatchTotal = 1;
        if (cssSelector) {
            try {
                const cssAll = document.querySelectorAll(cssSelector);
                cssMatchTotal = cssAll.length;
                if (cssAll.length > 1) {
                    cssMatchIndex = getMatchIndexByPosition(cssAll, element);
                }
            } catch (_) {}
        }

        // 计算文本匹配索引
        let textMatchIndex = 0;
        let textMatchTotal = 1;
        if (text) {
            const textAll = findElementsByText(text);
            textMatchTotal = textAll.length;
            if (textAll.length > 1) {
                textMatchIndex = getMatchIndexByPosition(textAll, element);
            }
        }

        iframeXpathList = []
        for (let i = 0; i < result.iframes.length; i++){
            iframeXpathList.push({"value": getRelativeXPath(result.iframes[i]), "index": 0, "url": result.iframes[i].src, "locationType": "xpath"})
        }

        const vw = window.innerWidth || document.documentElement.clientWidth;
        const vh = window.innerHeight || document.documentElement.clientHeight;

        return {
            success: true,
            value: xpath,
            cssSelector: cssSelector,
            cssMatchIndex: cssMatchIndex,
            cssMatchTotal: cssMatchTotal,
            text: text,
            textMatchIndex: textMatchIndex,
            textMatchTotal: textMatchTotal,
            index: index,
            iframes: iframeXpathList,
            tagName: element.tagName.toLowerCase(),
            x: x,
            y: y,
            boundingBox: { x: boundingBox.x, y: boundingBox.y, width: boundingBox.width, height: boundingBox.height },
            viewportSize: { width: vw, height: vh },
            locationType: "xpath"
        };
    }

    // 将工具函数暴露到全局对象
    window.__elementLocatorUtils = {
        getElementInfoByCoordinates: getElementInfoByCoordinates,
        getRelativeXPath: getRelativeXPath,
        getRelativeSelector: getRelativeSelector,
        getElementText: getElementText,
        getElementIndex: getElementIndex,
        isSameElement: isSameElement,
        version: '1.0.0'
    };

    console.log('[ElementLocator] 元素定位工具已注入，版本:', window.__elementLocatorUtils.version);
})();